"""MetricMind application package."""
